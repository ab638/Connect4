Programmer: Austin Brummett
Assignment: Project 3 - curses and gdbm
Instructor: Dr. Tony Richardson
Class: CS375

Project Choice: Connect 4
Features:
* Title Screen and Goodbye Screen
* Shows both current wins in that gameplay session &
  total wins player has occured over multiple playthroughs
* Animated Pieces that blink on user win
* '*' marker to show which player's turn it is

How to Play:
* Find a friend or play alone
* Enter each player's name
* Press the down arrow to drop a piece
* Move pieces using the left or right arrow
* Get 4 in a row
* if you want to continue after the game is over press 'y' else press 'n'
* you can quit at any time by pressing 'q'


