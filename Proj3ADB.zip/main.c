#include "connect4.h"

GDBM_FILE dbf;

Player p[2];
WINDOW *board, *prompt, *title;
int xmax, ymax, boardState[8][9], winningPositions[2][7], 
    colorChoice[2] = {0}, curPointsPlayer[2], turn, fullColumns = 0;
char players[2][30];

int main(){
	for(int i =0; i < 2; i++)
		curPointsPlayer[i] = 0;	
	
	Initialize();
	getmaxyx(stdscr, ymax, xmax); 
	drawTitle(0); // draw the title
	napms(1500); // nap for 1500ms
	playerSelect(); // get names
	drawBoardLayout(); // draw layout
	Play(); // play the game
	Quit(); // end screen
	endwin();

	return 0;
}
